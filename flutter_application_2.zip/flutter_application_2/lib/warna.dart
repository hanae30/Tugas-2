import 'package:flutter/material.dart';

Color warna1 = Color(0xffFFFFFF);
Color warna2 = Color(0xff000000);

TextStyle satu = TextStyle(
  color: warna1,
  //fontSize: 15
);

TextStyle dua = TextStyle(
    color: warna1,
    //fontSize: 15,
    fontWeight: FontWeight.w700);

TextStyle tiga =
    TextStyle(color: warna2, fontSize: 15, fontWeight: FontWeight.w700);

TextStyle empat = TextStyle(
  color: warna2,
  //fontSize: 15
);
