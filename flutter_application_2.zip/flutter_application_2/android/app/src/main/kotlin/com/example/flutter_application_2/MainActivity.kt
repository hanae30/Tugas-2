package com.example.flutter_application_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
